/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.clinica.levantate.lazara._0;

/**
 *
 * @author usuario
 */
public class ClinicaLevantateLazara1_0 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
