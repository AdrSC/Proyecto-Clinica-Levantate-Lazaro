package modelo;

import java.time.LocalDate;

public class HistoriaClinica {

    private int idHistoria;
    private LocalDate fechaApertura;
    private String observaciones;
    private int idPaciente;

    public HistoriaClinica() {
    }

    public HistoriaClinica(LocalDate fechaApertura, String observaciones, int idPaciente) {
        this.fechaApertura = fechaApertura;
        this.observaciones = observaciones;
        this.idPaciente = idPaciente;
    }

    public int getIdHistoria() {
        return idHistoria;
    }

    public void setIdHistoria(int idHistoria) {
        this.idHistoria = idHistoria;
    }

    public LocalDate getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(LocalDate fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }
}