package pruebas;

import dao.MedicoDAO;
import java.util.ArrayList;
import modelo.Medico;

public class PruebaMedicoDAO {

    public static void main(String[] args) {

        MedicoDAO dao = new MedicoDAO();

        Medico medico = new Medico(
                "CMP001",
                "Carlos",
                "Ramirez Torres",
                "987654321",
                "carlos.ramirez@clinica.com",
                1
        );

        boolean registrado = dao.registrar(medico);

        if (registrado) {
            System.out.println("Médico registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar el médico.");
        }

        System.out.println("Listado de médicos:");

        ArrayList<Medico> lista = dao.listar();

        for (Medico m : lista) {
            System.out.println(
                    m.getIdMedico() + " - "
                    + m.getCmp() + " - "
                    + m.getNombres() + " "
                    + m.getApellidos()
                    + " | Especialidad ID: " + m.getIdEspecialidad()
            );
        }
    }
}