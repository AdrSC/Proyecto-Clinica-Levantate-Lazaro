package pruebas;

import dao.HistoriaClinicaDAO;
import java.time.LocalDate;
import java.util.ArrayList;
import modelo.HistoriaClinica;

public class PruebaHistoriaClinicaDAO {

    public static void main(String[] args) {

        HistoriaClinicaDAO dao = new HistoriaClinicaDAO();

        int idPaciente = 1;

        HistoriaClinica historiaExistente = dao.buscarPorPaciente(idPaciente);

        if (historiaExistente == null) {

            HistoriaClinica historia = new HistoriaClinica(
                    LocalDate.now(),
                    "Historia clínica aperturada para el paciente.",
                    idPaciente
            );

            boolean registrado = dao.registrar(historia);

            if (registrado) {
                System.out.println("Historia clínica registrada correctamente.");
            } else {
                System.out.println("No se pudo registrar la historia clínica.");
            }

        } else {
            System.out.println("El paciente ya tiene historia clínica registrada.");
            System.out.println("ID Historia: " + historiaExistente.getIdHistoria());
        }

        System.out.println("Listado de historias clínicas:");

        ArrayList<HistoriaClinica> lista = dao.listar();

        for (HistoriaClinica h : lista) {
            System.out.println(
                    h.getIdHistoria() + " - "
                    + h.getFechaApertura()
                    + " | Paciente ID: " + h.getIdPaciente()
                    + " | Observaciones: " + h.getObservaciones()
            );
        }
    }
}