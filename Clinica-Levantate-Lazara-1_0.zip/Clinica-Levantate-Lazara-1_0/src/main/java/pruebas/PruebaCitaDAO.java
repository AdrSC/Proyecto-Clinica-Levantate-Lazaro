package pruebas;

import dao.CitaDAO;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import modelo.Cita;

public class PruebaCitaDAO {

    public static void main(String[] args) {

        CitaDAO dao = new CitaDAO();

        Cita cita = new Cita(
                LocalDate.of(2026, 6, 25),
                LocalTime.of(10, 30),
                "Programada",
                1,
                1
        );

        boolean registrado = dao.registrar(cita);

        if (registrado) {
            System.out.println("Cita registrada correctamente.");
        } else {
            System.out.println("No se pudo registrar la cita.");
        }

        System.out.println("Listado de citas:");

        ArrayList<Cita> lista = dao.listar();

        for (Cita c : lista) {
            System.out.println(
                    c.getIdCita() + " - "
                    + c.getFecha() + " "
                    + c.getHora()
                    + " | Estado: " + c.getEstado()
                    + " | Paciente ID: " + c.getIdPaciente()
                    + " | Médico ID: " + c.getIdMedico()
            );
        }
    }
}