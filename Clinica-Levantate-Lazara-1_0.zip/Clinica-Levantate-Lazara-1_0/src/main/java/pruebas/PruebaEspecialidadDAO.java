package pruebas;

import dao.EspecialidadDAO;
import java.util.ArrayList;
import modelo.Especialidad;

public class PruebaEspecialidadDAO {

    public static void main(String[] args) {

        EspecialidadDAO dao = new EspecialidadDAO();

        Especialidad especialidad = new Especialidad(
                "Medicina General",
                "Atención médica general para pacientes."
        );

        boolean registrado = dao.registrar(especialidad);

        if (registrado) {
            System.out.println("Especialidad registrada correctamente.");
        } else {
            System.out.println("No se pudo registrar la especialidad.");
        }

        System.out.println("Listado de especialidades:");

        ArrayList<Especialidad> lista = dao.listar();

        for (Especialidad e : lista) {
            System.out.println(e.getIdEspecialidad() + " - " + e.getNombreEspecialidad());
        }
    }
}