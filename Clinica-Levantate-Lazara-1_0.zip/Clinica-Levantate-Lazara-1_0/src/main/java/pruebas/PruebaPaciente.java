package pruebas;

import dao.PacienteDAO;
import java.time.LocalDate;
import modelo.Paciente;

public class PruebaPaciente {

    public static void main(String[] args) {

        Paciente paciente = new Paciente(
                "12345679",
                "Danna",
                "Flores Lara",
                LocalDate.of(2004, 5, 12),
                "F",
                "987654321",
                "danna@gmail.com",
                ""
        );

        PacienteDAO dao = new PacienteDAO();

        boolean registrado = dao.registrar(paciente);

        if (registrado) {
            System.out.println("Paciente registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar el paciente.");
        }
    }
}