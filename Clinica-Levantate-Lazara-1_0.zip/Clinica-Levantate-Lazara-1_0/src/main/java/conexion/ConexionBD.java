package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL = "jdbc:sqlserver://localhost:1433;"
            + "databaseName=ClinicaLevantateLazaro;"
            + "encrypt=true;"
            + "trustServerCertificate=true;";

    private static final String USUARIO = "sa";
    private static final String PASSWORD = "Inventario2026*";

    public static Connection obtenerConexion() {
        Connection conexion = null;

        try {
            conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            System.out.println("Detalle: " + e.getMessage());
        }

        return conexion;
    }
}