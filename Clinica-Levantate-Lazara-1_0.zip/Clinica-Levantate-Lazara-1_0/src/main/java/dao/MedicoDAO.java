package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Medico;

public class MedicoDAO {

    public boolean registrar(Medico medico) {
        String sql = "INSERT INTO MEDICO "
                + "(cmp, nombres, apellidos, telefono, correo, id_especialidad) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, medico.getCmp());
            ps.setString(2, medico.getNombres());
            ps.setString(3, medico.getApellidos());
            ps.setString(4, medico.getTelefono());
            ps.setString(5, medico.getCorreo());
            ps.setInt(6, medico.getIdEspecialidad());

            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar médico.");
            System.out.println("Detalle: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Medico> listar() {
        ArrayList<Medico> lista = new ArrayList<>();

        String sql = "SELECT id_medico, cmp, nombres, apellidos, telefono, correo, id_especialidad "
                + "FROM MEDICO";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Medico medico = new Medico();

                medico.setIdMedico(rs.getInt("id_medico"));
                medico.setCmp(rs.getString("cmp"));
                medico.setNombres(rs.getString("nombres"));
                medico.setApellidos(rs.getString("apellidos"));
                medico.setTelefono(rs.getString("telefono"));
                medico.setCorreo(rs.getString("correo"));
                medico.setIdEspecialidad(rs.getInt("id_especialidad"));

                lista.add(medico);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar médicos.");
            System.out.println("Detalle: " + e.getMessage());
        }

        return lista;
    }
}