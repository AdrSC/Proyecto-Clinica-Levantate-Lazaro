package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import modelo.HistoriaClinica;

public class HistoriaClinicaDAO {

    public boolean registrar(HistoriaClinica historia) {
        String sql = "INSERT INTO HISTORIA_CLINICA "
                + "(fecha_apertura, observaciones, id_paciente) "
                + "VALUES (?, ?, ?)";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(historia.getFechaApertura()));
            ps.setString(2, historia.getObservaciones());
            ps.setInt(3, historia.getIdPaciente());

            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar historia clínica.");
            System.out.println("Detalle: " + e.getMessage());
            return false;
        }
    }

    public HistoriaClinica buscarPorPaciente(int idPaciente) {
        String sql = "SELECT id_historia, fecha_apertura, observaciones, id_paciente "
                + "FROM HISTORIA_CLINICA WHERE id_paciente = ?";

        HistoriaClinica historia = null;

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setInt(1, idPaciente);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    historia = new HistoriaClinica();

                    historia.setIdHistoria(rs.getInt("id_historia"));
                    historia.setFechaApertura(rs.getDate("fecha_apertura").toLocalDate());
                    historia.setObservaciones(rs.getString("observaciones"));
                    historia.setIdPaciente(rs.getInt("id_paciente"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar historia clínica.");
            System.out.println("Detalle: " + e.getMessage());
        }

        return historia;
    }

    public ArrayList<HistoriaClinica> listar() {
        ArrayList<HistoriaClinica> lista = new ArrayList<>();

        String sql = "SELECT id_historia, fecha_apertura, observaciones, id_paciente "
                + "FROM HISTORIA_CLINICA";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                HistoriaClinica historia = new HistoriaClinica();

                historia.setIdHistoria(rs.getInt("id_historia"));
                historia.setFechaApertura(rs.getDate("fecha_apertura").toLocalDate());
                historia.setObservaciones(rs.getString("observaciones"));
                historia.setIdPaciente(rs.getInt("id_paciente"));

                lista.add(historia);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar historias clínicas.");
            System.out.println("Detalle: " + e.getMessage());
        }

        return lista;
    }
}