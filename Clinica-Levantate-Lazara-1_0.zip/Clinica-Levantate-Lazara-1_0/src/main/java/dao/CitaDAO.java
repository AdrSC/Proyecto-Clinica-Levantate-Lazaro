package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import modelo.Cita;

public class CitaDAO {

    public boolean registrar(Cita cita) {
        String sql = "INSERT INTO CITA "
                + "(fecha, hora, estado, id_paciente, id_medico) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(cita.getFecha()));
            ps.setTime(2, Time.valueOf(cita.getHora()));
            ps.setString(3, cita.getEstado());
            ps.setInt(4, cita.getIdPaciente());
            ps.setInt(5, cita.getIdMedico());

            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar cita.");
            System.out.println("Detalle: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Cita> listar() {
        ArrayList<Cita> lista = new ArrayList<>();

        String sql = "SELECT id_cita, fecha, hora, estado, id_paciente, id_medico FROM CITA";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cita cita = new Cita();

                cita.setIdCita(rs.getInt("id_cita"));
                cita.setFecha(rs.getDate("fecha").toLocalDate());
                cita.setHora(rs.getTime("hora").toLocalTime());
                cita.setEstado(rs.getString("estado"));
                cita.setIdPaciente(rs.getInt("id_paciente"));
                cita.setIdMedico(rs.getInt("id_medico"));

                lista.add(cita);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar citas.");
            System.out.println("Detalle: " + e.getMessage());
        }

        return lista;
    }
}