package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Especialidad;

public class EspecialidadDAO {

    public boolean registrar(Especialidad especialidad) {
        String sql = "INSERT INTO ESPECIALIDAD (nombre_especialidad, descripcion) VALUES (?, ?)";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, especialidad.getNombreEspecialidad());
            ps.setString(2, especialidad.getDescripcion());

            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar especialidad.");
            System.out.println("Detalle: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Especialidad> listar() {
        ArrayList<Especialidad> lista = new ArrayList<>();

        String sql = "SELECT id_especialidad, nombre_especialidad, descripcion FROM ESPECIALIDAD";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Especialidad especialidad = new Especialidad();

                especialidad.setIdEspecialidad(rs.getInt("id_especialidad"));
                especialidad.setNombreEspecialidad(rs.getString("nombre_especialidad"));
                especialidad.setDescripcion(rs.getString("descripcion"));

                lista.add(especialidad);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar especialidades.");
            System.out.println("Detalle: " + e.getMessage());
        }

        return lista;
    }
}