package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import modelo.Paciente;

public class PacienteDAO {

    public boolean registrar(Paciente paciente) {
        String sql = "INSERT INTO PACIENTE "
                + "(dni, nombres, apellidos, fecha_nacimiento, sexo, telefono, correo, direccion) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, paciente.getDni());
            ps.setString(2, paciente.getNombres());
            ps.setString(3, paciente.getApellidos());

            // Convierte LocalDate a java.sql.Date para SQL Server
            ps.setDate(4, Date.valueOf(paciente.getFechaNacimiento()));

            ps.setString(5, paciente.getSexo());
            ps.setString(6, paciente.getTelefono());
            ps.setString(7, paciente.getCorreo());
            ps.setString(8, paciente.getDireccion());

            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar paciente.");
            System.out.println("Detalle: " + e.getMessage());
            return false;
        }
    }
}